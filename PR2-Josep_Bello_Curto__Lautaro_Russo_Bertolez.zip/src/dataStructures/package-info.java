/**
 * Package amb totes les estructures de dades que es demanene en la pr�ctica
 */
package dataStructures;
