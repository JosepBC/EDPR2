	/**
 * Package amb tots els algorismes demanats sobre les estructures de dades del a pr�ctica
 */
package algorithms;
